## Descrição dos Experimentos:

**Data:** 2023-06-29 18:48:45.456401462-03:00

**Tipo de ataque:** Slowloris
**Tempo de duração:** 5 minutos (300 segundos)
**Tempode de ataque:** 3 minutos (60/240 segundo)
**Total de nodes utilizados:** IDS-DF, IDS-GO, IDS-PE, WHX-PA, WHX-ES.

## Tipos de instância

### Clientes

Duas variantes:

* Clientes requisitando conteúdo estático, a cada $500ms$, denominado $Estático$

* Clientes requisitando conteúdo dinâmico aleatoriamente entre $[1, 30]$ segundos, denominado $Dinâmico$

### Atacantes

* Atacantes utilizando o script

## Servidor Web

O Servidor Web utilizado é o Apache 2.4.56, baseado na imagem Docker do sistema operacional Debian (debian-slim). Este servidor Web está escutando na porta 80/TCP por conexões.

### Cenário 1

| Cenário | Nº Clientes (Tipo) | Intervalo de Requisição | N# Atacantes | Nº Sockets |
| ------- | ------------------ | ----------------------- | ------------ | ---------- |
| C1-E1   | 1 ($Estático$)     | $500ms$                 | 1            | 150        |
| C1-E2   | 1 ($Estático$)     | $500ms$                 | 1            | 300        |
| C1-E3   | 1 ($Dinâmico$)     | $[1, 30]s$              | 1            | 150        |
| C1-E4   | 1 ($Dinâmico$)     | $[1, 30]s$              | 1            | 300        |

#### Resultados Cenário 1

Como podemos observar na Figura 1, o cliente recebe respostas do servidor no cenário C1-E1, contudo há dois intervalos onde o serviço foi negado.  Já nos cenários C1-E2 (Figura 2) e C1-E4 (Figura 3) há apenas uma queda do serviço. Por fim, experimento C1-E3 (Figura 4) é possível observar quedas de serviço mais significativas.

![Cenario1_Experimento1.png](img//Cenario1_Experimento1.png)

<div><center>Figura 1) Requisições respondidas (C1-E1)</center></div>

![Cenario1_Experimento2.png](img//Cenario1_Experimento2.png)

Figura 2) Requisições respondidas (C1-E2)

![Cenario1_Experimento4.png](img//Cenario1_Experimento4.png)

Figura 3) Requisições respondidas (C1-E4)

![Cenario1_Experimento3.png](img//Cenario1_Experimento3.png)

Figura 4) Requisições respondidas (C1-E3)

#### Cenário 1 - Distribuição do Ataque

##### Servidor;

**Node:** WHX-ES.
**Numero de pods:** 3
**Pods:** server, tschark, client-monitor.

##### Cliente;

**Node;** IDS-PE.
**Numero de pods:** 1
**Pods:** cliente | random-client

##### Atacante;

**Node:** IDS-GO.
**Numero de pods:** 1
**Pods:** atacantes (default sockets) | atacantes (random sockets)

### Cenário 2

| Cenário | Nº Clientes (Tipo) | Intervalo de Requisição | N# Atacantes | Nº Sockets |
| ------- | ------------------ | ----------------------- | ------------ | ---------- |
| C2-E1   | 315 ($Estático$)   | $500ms$                 | 35           | 150        |
| C2-E2   | 1 ($Estático$)     | $500ms$                 | 35           | 300        |
| C2-E3   | 315 ($Dinâmico$)   | $[1, 30]s$              | 35           | 150        |
| C2-E4   | 315 ($Dinâmico$)   | $[1, 30]s$              | 35           | 300        |

#### Resultados Cenário 2

Em Figura 5 é possível observar a interrupção de serviço intensiva durante o ataque no cenário C2-E1, com algumas respostas esporádicas. Além disso a Figura 6 e 7 ilustram os diferentes patamares de vazão entre o C1-E1 e C2-E1, respectivamente.  Por fim, o cenário C2-E3 e C2-E4 (Figuras 8 e 9) demonstram um perfil de vazão distinto, devido aos clientes variados.

![Cenario2_Experimento1.png](img//Cenario2_Experimento1.png)

Figura 5) Requisições respondidas (C2-E1)

![Cenario1_Experimento1_vazao.png](img//Cenario1_Experimento1_vazao.png)

Figura 6) Vazão no cenário C1-E1

![Cenario2_Experimento1_vazao.png](img//Cenario2_Experimento1_vazao.png)

Figura 7) Vazão no cenário C2-E1

![Cenario2_Experimento3_vazao.png](img//Cenario2_Experimento3_vazao.png)

Figura 8) Vazão no cenário C2-E3

![Cenario2_Experimento4_vazao.png](img//Cenario2_Experimento4_vazao.png)

Figura 9) Vazão no cenário C2-E4

##### Cenário 2 - Distribuição do Ataque

**Servidor;** 
**Node:** WHX-ES.
**Numero de pods:** 3
**Pods:** server, tschark, client-monitor.

**Cliente;**
**Node:** IDS-PE.
**Numero de pods:** 90
**Pods:** cliente | random-client

**Cliente;**
**Node;** IDS-DF.
**Numero de pods:** 90
**Pods:** cliente | random-client

**Cliente;**
**Node;** IDS-GO.
**Numero de pods:** 90
**Pods:** cliente | random-client

**Cliente;**
**Node:** WHX-PA.
**Numero de pods:** 45
**Pods:** cliente | random-client

**Atacante;**
**Node:** IDS-PE.
**Numero de pods:** 10
**Pods:** atacantes (default sockets) | atacantes (random sockets)

**Atacante;**
**Node:** IDS-DF.
**Numero de pods:** 10
**Pods:** atacantes (default sockets) | atacantes (random sockets)

**Atacante;**
**Node:** IDS-GO.
**Numero de pods:** 10
**Pods:** atacantes (default sockets) | atacantes (random sockets)

**Atacante;**
**Node:** WHX-PA.
**Numero de pods:** 5
**Pods:** atacantes (default sockets) | atacantes (random sockets)

### Cenário 3

| Cenário | Nº Clientes (Tipo)                    | Intervalo de Requisição | N# Atacantes (Sockets) |
| ------- | ------------------------------------- | ----------------------- | ---------------------- |
| C3-E1   | 157 ($Estático$)<br/>157 ($Dinâmico$) | $500ms$ e $[1, 30]s$    | 18 (150)<br/>18 (300)  |

#### Resultados Cenário 3

O cenário 3 inclui uma mistura de clientes e atacantes distintos, visando obter um comportamento distinto dos demais cenários. Em Figura 10 é possível observar a quantidade de respostas obtidas pelas 314 instâncias de clientes em agregado, nota-se também um intervalo de serviço negado com períodos onde requisições foram atendidas.

![Cenario3_Experimento1_agregado.png](img//Cenario3_Experimento1_agregado.png)

Figura 10) Requisições HTTP respondidas (agregado) (C3-E1)

Ja a Figura 11 demonstra a vazão durante o cenário, incluindo picos que coincidem com as respostas obtidas do servidor web.

![Cenario3_Experimento1_vazao.png](img//Cenario3_Experimento1_vazao.png)

Figura 11) Vazão no cenário C3-E1

##### Cenário 3 - Distribuição do Ataque

**Servidor;** 
**Node:** WHX-ES.
**Numero de pods:** 3
**Pods:** server, tschark, client-monitor.

**Cliente;**
**Node:** IDS-PE.
**Numero de pods:** 45
**Pods:** cliente 

**Cliente;**
**Node:** IDS-DF.
**Numero de pods:** 45
**Pods:** cliente

**Cliente;**
**Node:** IDS-GO.
**Numero de pods:** 45
**Pods:** cliente

**Cliente;**
**Node:** WHX-PA.
**Numero de pods:** 22
**Pods:** cliente 

**Cliente;**
**Node:** IDS-PE.
**Numero de pods:** 45
**Pods:** random-client

**Cliente;**
**Node:** IDS-DF.
**Numero de pods:** 45
**Pods:** random-client

**Cliente:**
**Node:** IDS-GO.
**Numero de pods:** 45
**Pods:** random-client

**Cliente;**
**Node:** WHX-PA.
**Numero de pods:** 22
**Pods:** random-client

**Atacante;**
**Node:** IDS-PE.
**Numero de pods:** 5
**Pods:** atacantes (default sockets)

**Atacante;**
**Node:** IDS-DF.
**Numero de pods:** 5
**Pods:** atacantes (default sockets)

**Atacante;**
**Node:** IDS-GO.
**Numero de pods:** 5
**Pods:** atacantes (default sockets)

**Atacante;**
**Node:** WHX-PA.
**Numero de pods:** 3
**Pods:** atacantes (default sockets)

**Atacante;**
**Node:** IDS-PE.
**Numero de pods:** 5
**Pods:** atacantes (random sockets)

**Atacante;**
**Node:** IDS-DF.
**Numero de pods:** 5
**Pods:** atacantes (random sockets)

**Atacante;**
**Node:** IDS-GO.
**Numero de pods:** 5
**Pods:** atacantes (random sockets)

**Atacante;**
**Node:** WHX-PA.
**Numero de pods:** 3
**Pods:** atacantes (random sockets)
